package com.perpeer.bitcointicker.data.cache

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.perpeer.bitcointicker.data.model.Coin

/**
 * Created by Pelşin KAPLAN on 6.01.2025.
 */

@Database(entities = [Coin::class], version = 1, exportSchema = false)
abstract class CacheDatabase : RoomDatabase() {

    abstract fun getCacheDao(): CacheDao

    companion object {
        private var instance: CacheDatabase? = null

        fun getInstance(context: Context): CacheDatabase? {
            if (instance == null) {
                instance = Room.databaseBuilder(
                    context,
                    CacheDatabase::class.java,
                    "cache.db"
                ).build()
            }
            return instance
        }
    }
}