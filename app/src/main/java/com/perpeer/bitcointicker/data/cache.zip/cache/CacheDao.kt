package com.perpeer.bitcointicker.data.cache

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import com.perpeer.bitcointicker.data.model.Coin

/**
 * Created by Pelşin KAPLAN on 6.01.2025.
 */
@Dao
interface CacheDao {
    @Insert
    suspend fun insert(coin: Coin)

    @Query("SELECT * FROM cache_table")
    suspend fun getAll(): List<Coin>

    @Delete
    suspend fun delete(data: Coin)

    @Query("SELECT * FROM cache_table where `id` = :key")
    suspend fun getData(key: String): Coin

}