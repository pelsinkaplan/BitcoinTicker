package com.perpeer.bitcointicker.data.cache

import android.content.Context
import com.perpeer.bitcointicker.data.model.Coin
import javax.inject.Inject

/**
 * Created by Pelşin KAPLAN on 6.01.2025.
 */
class CacheManager @Inject constructor(
    context: Context
) {

    private val cacheDatabase: CacheDatabase = CacheDatabase.getInstance(context)!!

    suspend fun insertDataAtCache(data: Coin) {
        cacheDatabase.getCacheDao().insert(data)
    }

    suspend fun deleteDataAtCache(key: String) {
        cacheDatabase.getCacheDao().delete(getCacheModelWithKey(key))
    }

    suspend fun getAllDataAtCache(): List<Coin> {
        return cacheDatabase.getCacheDao().getAll()
            .map { it }
    }

    private suspend fun getCacheModelWithKey(key: String): Coin =
        cacheDatabase.getCacheDao().getData(key)


    suspend fun getDataWithKey(key: String): Coin =
        cacheDatabase.getCacheDao().getData(key)


    suspend fun controlCache(key: String): Coin? =
        try {
            cacheDatabase.getCacheDao().getData(key)
        } catch (e: Exception) {
            null
        }

    companion object {
        val cacheManager: CacheManager by lazy {
            CacheManager(applicationContext)
        }
        private lateinit var applicationContext: Context

        fun initialize(context: Context) {
            applicationContext = context
        }
    }
}